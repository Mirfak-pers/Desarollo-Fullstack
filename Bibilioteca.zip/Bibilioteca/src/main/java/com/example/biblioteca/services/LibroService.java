package com.example.biblioteca.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.biblioteca.model.Libro;
import com.example.biblioteca.repository.LibroRepository;

@Service

public class LibroService {
	@Autowired
	private LibroRepository libroRepository;
	
	public List<Libro> getLibros(){
		return libroRepository.obtenerLibros();
	}
	
	public Libro getLibroById(int id){
		return libroRepository.buscarPorId(id);
	}
	
	public Libro saveLibro(Libro lib){
		return libroRepository.guardar(lib);
	}
	
	public Libro updateLibro(Libro lib){
		return libroRepository.actualizar(lib);
	}
	
	public String deleteLibro(int id) {
		libroRepository.eliminar(id);
		return "Libro eliminado";
	}
}
